package guessword;

class WordCheck {
	protected String word;
	protected boolean[] mask;
	
	/**
	 * Constructs this word checker from the specified word
	 * @param word The word that the user is trying to guess
	 */
	public WordCheck(String word) {
		this.word = word;
		mask = new boolean[word.length()];
	}
	
	/**
	 * Gets the word that the user is trying to guess
	 * @return The word
	 */
	public String getWord() {
		return word;
	}
	
	/**
	 * Gets display version of the word, which has underscores for letters
	 * that the user hasn't yet guessed
	 * @return The display version of the word
	 */
	public String getDisplay() {
		String display = "";
		for (int c = 0; c < word.length(); c++) {
			if (mask[c])
				display += word.charAt(c);
			else
				display += '_';
		}
		return display;
	}
	
	/**
	 * Checks the letter guessed by the user against the word
	 * @param ch The letter guessed by the user
	 * @return True if letter exists in the word
	 */
	public boolean guessLetter(char ch) {
		for (int c = 0; c < word.length(); c++) {
			if (word.charAt(c) == ch)
				mask[c] = true;
		}
		
		return word.contains("" + ch);
	}
	
	/**
	 * Checks to see if word has been guessed completely
	 * @return True if word is completely guessed
	 */
	public boolean isComplete() {
		boolean complete = true;
		for (boolean m: mask) {
			if (!m)
				complete = false;
		}
		return complete;
	}
}
