package guessword;

import java.io.*;

public class GuessWord {
	protected static int numChances = 9;
	
	/**
	 * Main method for this application
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader reader = new BufferedReader(in);
		System.out.println("GuessWord v8");
		
		WordCheck word = new WordCheck(WordList.getRandomWord());
		//System.out.println("Word is: " + word.getWord());

		while (true) {
			System.out.print("Guess a letter: ");
			String line = reader.readLine();
			
			// Break out of this loop if user types 'exit'
			if (line.equals("exit"))
				break;
			
			boolean result = word.guessLetter(line.charAt(0));
			if (!result)
				numChances--;
			
			// Check to see if game is over because user has used up all chances
			if (numChances == 0) {
				System.out.println("You lose!");
				break;				
			}
			
			System.out.print(result ? "Correct" : "Wrong");
			System.out.println(", so far: " + word.getDisplay() + " (" + numChances + " chances left)");
			
			if (word.isComplete()) {
				System.out.println("You win!");
				break;
			}
		}

	}

}
