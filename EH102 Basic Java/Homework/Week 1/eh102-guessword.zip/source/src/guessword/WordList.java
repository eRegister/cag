package guessword;

class WordList {
	protected static String[] words = {
		"mouse", "lion", "elephant", "tiger",
		"centipede", "mosquito", "giraffe"
	};
	
	/**
	 * Gets a random word from the word list
	 * @return A random word
	 */
	public static String getRandomWord() {
		int index = (int)(Math.random() * words.length);
		return words[index];
	}
}
