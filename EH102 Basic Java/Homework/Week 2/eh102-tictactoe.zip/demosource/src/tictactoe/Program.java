package tictactoe;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Program {

	protected boolean xturn = true;
	
	protected Board board = new Board();
	
	public void run() {
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader reader = new BufferedReader(in);
		String input;
		int state = 0;
		int moves = 0;
		do {
			board.draw();
			
			System.out.print("Player " + (xturn ? 'X' : 'O') + ", enter a row: ");
			try {
				input = reader.readLine();
				
				if (input.toLowerCase().equals("q"))
					break;
				int row = Integer.parseInt(input) - 1;
				
				System.out.print("Player " + (xturn ? 'X' : 'O') + ", enter a column: ");
				input = reader.readLine();
				if (input.toLowerCase().equals("q"))
					break;
				int col = Integer.parseInt(input) - 1;
				
				// Check for previous move at that location
				if (!board.allowMove(row, col)) {
					System.out.println("Invalid move");
					continue;
				}
				
				moves++;
				board.recordMove(row, col, xturn);
				
			} catch (IOException e) {
			}
			
			if (moves == 9) {
				state = -1;
				break;
			}
			
			xturn = !xturn;
			state = board.checkState();
		}
		while (state == 0);
		
		board.draw();
		
		switch (state) {
		case 0:
			System.out.println("Player quit");
			break;
		case 1:
			System.out.println("Player X wins!");
			break;
		case 2:
			System.out.println("Player O wins!");
			break;
		case -1:
			System.out.println("Nobody wins");
			break;
		}
	
	}
	
	/**
	 * The main method
	 * @param args
	 */
	public static void main(String[] args) {
		new Program().run();
	}
}
