package tictactoe;

public class Board {
	protected int[][] board = new int[3][3];
	
	public Board() {
	}
	
	/**
	 * Records a move made by a player on the board
	 * @param row the row
	 * @param col the column
	 * @param x true for player x, false for player o
	 */
	public void recordMove(int row, int col, boolean x) {
		board[row][col] = x ? 1 : 2;
	}
	
	/**
	 * Checks if a player is allowed to make a move at the given location
	 * @param row the row
	 * @param col the column
	 * @return true if player can move, else false
	 */
	public boolean allowMove(int row, int col) {
		return board[row][col] == 0;
	}
	
	/**
	 * Draws the board to the console
	 */
	public void draw() {
		for (int j = 0; j < 3; j++) {
			for (int i = 0; i < 3; i++) {
				if (board[j][i] == 0)
					System.out.print('-');
				else if (board[j][i] == 1)
					System.out.print('X');
				else if (board[j][i] == 2)
					System.out.print('O');
			}
			System.out.println();
		}
	}
	
	/**
	 * Checks the state of the board to see if either player has won
	 * @return Who has won: 0 = neither, 1 = player X, 2 = player O
	 */
	public int checkState() {
		// Check rows
		for (int j = 0; j < 3; ++j) {
			if (board[j][0] > 0 && board[j][0] == board[j][1] && board[j][0] == board[j][2])
				return board[j][0];
		}
		// Check cols
		for (int i = 0; i < 3; ++i) {
			if (board[0][i] > 0 && board[0][i] == board[1][i] && board[0][i] == board[2][i])
				return board[0][i];
		}
		// Check diagonals
		if (board[0][0] > 0 && board[0][0] == board[1][1] && board[0][0] == board[2][2])
			return board[0][0];
		if (board[2][0] > 0 && board[2][0] == board[1][1] && board[2][0] == board[0][2])
			return board[2][0];
		
		return 0;
	}
}
