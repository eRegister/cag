package eh102.jemr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class CSVReader extends BufferedReader {
	
	/**
	 * Constructor
	 * @param reader the reader to use
	 */
	public CSVReader(Reader reader) {
		super(reader);
	}
	
	/**
	 * Reads and parses a line from a CSV file
	 * @return an array of Strings
	 * @throws IOException
	 */
	public String[] readCSVLine() throws IOException {
		String line = readLine();
		if (line == null)
			return null;
		String[] vals = line.split(",");
		for (int i = 0; i < vals.length; i++)
			vals[i] = vals[i].trim();
		
		return vals;
	}
}
