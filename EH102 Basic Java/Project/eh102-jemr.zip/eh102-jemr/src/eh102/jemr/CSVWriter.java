package eh102.jemr;

import java.io.FileWriter;
import java.io.IOException;

public class CSVWriter extends FileWriter {

	/**
	 * Constructs a CSV writer from the specified file path
	 * @param path the file to write
	 * @throws IOException
	 */
	public CSVWriter(String path) throws IOException {
		super(path);
	}

	/**
	 * Writes an array of values as a line in this CSV file
	 * @param vals the array of values
	 * @throws IOException
	 */
	public void write(Object[] vals) throws IOException {
		for (int i = 0; i < vals.length; i++) {
			if (i > 0)
				write(",");
			String val = vals[i].toString();
			// Remove commas
			val = val.replace(',', ' ');
			write(val);
		}
		write("\r\n");
	}
}
