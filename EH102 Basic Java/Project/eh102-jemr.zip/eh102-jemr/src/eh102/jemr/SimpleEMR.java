package eh102.jemr;

import java.io.*;
import java.text.*;
import java.util.*;

public class SimpleEMR implements BasicEMR {
	protected static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	protected TreeSet<Patient> patients = new TreeSet<Patient>();
	protected TreeSet<User> users = new TreeSet<User>();
	protected static SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	protected int nextId;
	
	public String getWelcomeMessage() {
		return "SimpleEMR v1.0 [type help for usage]";
	}
	
	/**
	 * Loads the patients and users from a file
	 * @return true if successful, else false
	 */
	@Override
	public boolean load() {
		try {
			CSVReader readerPatients = new CSVReader(new FileReader("patients.csv"));
			CSVReader readerUsers = new CSVReader(new FileReader("users.csv"));			
			
			String[] vals = readerPatients.readCSVLine();
			while (vals != null) {
				int id = Integer.parseInt(vals[0]);
				String surname = vals[1];
				String forenames = vals[2];
				Patient.Gender gender = Patient.Gender.valueOf(vals[3]);
				Date dob = df.parse(vals[4]);
				String address = vals[5];
				
				patients.add(new Patient(id, surname, forenames, gender, dob, address));
				if (id >= nextId)
					nextId = id + 1;
				
				vals = readerPatients.readCSVLine();
			}
			
			vals = readerUsers.readCSVLine();
			while (vals != null) {
				int id = Integer.parseInt(vals[0]);
				String surname = vals[1];
				String forenames = vals[2];
				String login = vals[3];
				String password = vals[4];
				
				users.add(new User(id, surname, forenames, login, password));
				if (id >= nextId)
					nextId = id + 1;
				
				vals = readerUsers.readCSVLine();
			}
			
			readerUsers.close();
			readerPatients.close();
			
		} catch (IOException e) {
			return false;
		} catch (ParseException e) {
			return false;
		}
		return true;
	}
	
	/**
	 * Authenticates a user
	 * @param login the user login
	 * @param password the user password
	 */
	public boolean authenticateUser(String login, String password) {
		for (User u : users) {
			if (u.getLogin().equals(login) && u.getPassword().equals(password))
				return true;
		}
		return false;
	}
	
	/**
	 * Adds a patient to the EMR
	 */
	@Override
	public void addPatient() {
		try {
			System.out.print("Surname: ");
			String surname = reader.readLine().trim().toUpperCase();
			System.out.print("Forenames: ");
			String forenames = reader.readLine().trim();
			System.out.print("Gender (m/f): ");
			String strGender = reader.readLine().trim();
			Patient.Gender gender;
			if (strGender.equals("m"))
				gender = Patient.Gender.MALE;
			else if (strGender.equals("f"))
				gender = Patient.Gender.FEMALE;
			else
				gender = Patient.Gender.UNKNOWN;
			System.out.print("DOB (dd/mm/yyyy): ");
			String strDOB = reader.readLine().trim();
			Date dob = df.parse(strDOB);
			System.out.print("Address: ");
			String address = reader.readLine().trim();
			
			patients.add(new Patient(nextId++, surname, forenames, gender, dob, address));
		} catch (IOException e) {		
		} catch (ParseException e) {
		}
	}
	
	/**
	 * Adds a user to the EMR
	 */
	@Override
	public void addUser() {
		try {
			System.out.print("Surname: ");
			String surname = reader.readLine().trim().toUpperCase();
			System.out.print("Forenames: ");
			String forenames = reader.readLine().trim();
			System.out.print("Login: ");
			String login = reader.readLine().trim();
			System.out.print("Password: ");
			String password = reader.readLine().trim();
			
			users.add(new User(nextId++, surname, forenames, login, password));
		} catch (IOException e) {		
		}
	}
	
	/**
	 * Lists all the patients in the EMR
	 */
	@Override
	public void listPatients() {
		for (Patient p : patients)
			System.out.println(p.toString());
	}
	
	/**
	 * Lists all the users in the EMR
	 */
	@Override
	public void listUsers() {
		for (User u : users)
			System.out.println(u.toString());
	}
	
	/**
	 * Displays a patient from the EMR
	 * @param id the id of the patient to view
	 */
	@Override
	public void viewPatient(int id) {
		for (Patient p : patients) {
			if (p.getId() == id)
				p.printRecord();
		}
	}
	
	/**
	 * Finds patients in the EMR
	 * @param name the name of the patient to find
	 */
	@Override
	public void findPatients(String name) {
		for (Patient p : patients) {
			if (p.getSurname().contains(name.toUpperCase()))
				System.out.println(p.toString());
		}
	}
	
	/**
	 * Deletes a patient or user from the EMR
	 * @param id the id of the patient to delete
	 */
	@Override
	public void deletePerson(int id) {
		Patient pdel = null;
		User udel = null;
		for (Patient p : patients) {
			if (p.getId() == id) {
				pdel = p;
				break;
			}
		}
		for (User u : users) {
			if (u.getId() == id) {
				udel = u;
				break;
			}
		}
		
		if (pdel != null) {
			patients.remove(pdel);
			System.out.println("Deleted patient: " + pdel.getSurname() + ", " + pdel.getForenames());
		}
		else if (udel != null) {
			users.remove(udel);
			System.out.println("Deleted user: " + udel.getSurname() + ", " + udel.getForenames());
		}
	}
	
	/**
	 * Saves the patient records to a file
	 * @return true if successful, else false
	 */
	@Override
	public boolean save() {
		try {
			CSVWriter writerPatients = new CSVWriter("patients.csv");
			CSVWriter writerUsers = new CSVWriter("users.csv");
			
			for (Patient p : patients) {
				writerPatients.write(new Object[] {
					p.getId(),
					p.getSurname(),
					p.getForenames(),
					p.getGender(),
					df.format(p.getDob()),
					p.getAddress()
				});
			}
		
			for (User u : users) {
				writerUsers.write(new Object[] {
					u.getId(),
					u.getSurname(),
					u.getForenames(),
					u.getLogin(),
					u.getPassword()
				});
			}
			
			writerPatients.close();
			writerUsers.close();
		} catch (IOException e) {
			
		}
		
		return true;
	}
	
	public static DateFormat getDateFormat() {
		return df;
	}
}
