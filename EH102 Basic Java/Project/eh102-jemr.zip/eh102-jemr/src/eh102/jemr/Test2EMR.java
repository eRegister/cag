/**
 * 
 */
package eh102.jemr;

/**
 * @author Rowan
 *
 */
public class Test2EMR implements BasicEMR {

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#addPatient()
	 */
	@Override
	public void addPatient() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#addUser()
	 */
	@Override
	public void addUser() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#authenticateUser(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean authenticateUser(String login, String password) {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#deletePerson(int)
	 */
	@Override
	public void deletePerson(int id) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#findPatients(java.lang.String)
	 */
	@Override
	public void findPatients(String name) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#getWelcomeMessage()
	 */
	@Override
	public String getWelcomeMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#listPatients()
	 */
	@Override
	public void listPatients() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#listUsers()
	 */
	@Override
	public void listUsers() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#load()
	 */
	@Override
	public boolean load() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#save()
	 */
	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see eh103.proj.BasicEMR#viewPatient(int)
	 */
	@Override
	public void viewPatient(int id) {
		// TODO Auto-generated method stub

	}

}
