package eh102.jemr;

public class Person implements Comparable<Person> {

	protected int id;
	protected String surname;
	protected String forenames;

	/**
	 * Explicit constructor
	 * @param id the id
	 * @param surname the surname
	 * @param forenames the forenames
	 */
	public Person(int id, String surname, String forenames) {
		this.id = id;
		this.surname = surname;
		this.forenames = forenames;
	}

	/**
	 * Gets the ID
	 * @return the ID
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the ID
	 * @param id the ID
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the surname
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Sets the surname
	 * @param surname the surname
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getForenames() {
		return forenames;
	}

	public void setForenames(String forenames) {
		this.forenames = forenames;
	}
	
	@Override
	public int compareTo(Person p) {
		return surname.compareTo(p.surname);
	}
}