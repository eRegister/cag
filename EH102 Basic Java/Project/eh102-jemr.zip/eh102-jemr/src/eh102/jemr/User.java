package eh102.jemr;

public class User extends Person {
	protected String login;
	protected String password;
	
	public User(int id, String surname, String forenames, String login, String password) {
		super(id, surname, forenames);
		this.login = login;
		this.password = password;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return surname + ", " + forenames + " [User ID:" + id + "]";
	}
}
