package eh102.jemr;

import java.util.*;

public class Patient extends Person {
	enum Gender {
		MALE,
		FEMALE,
		UNKNOWN
	}
	
	protected Gender gender;
	protected Date dob;
	protected String address;
	
	/**
	 * Explicit constructor
	 * @param id
	 * @param surname
	 * @param forenames
	 * @param gender
	 * @param dob
	 */
	public Patient(int id, String surname, String forenames, Gender gender, Date dob, String address) {
		super(id, surname, forenames);
		this.gender = gender;
		this.dob = dob;
		this.address = address;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String toString() {
		return surname + ", " + forenames + " [Patient ID:" + id + "]";
	}
	
	public void printRecord() {
		System.out.println("ID:        " + id);
		System.out.println("Surname:   " + surname);
		System.out.println("Forenames: " + forenames);
		System.out.println("Gender:    " + gender);
		System.out.println("DOB:       " + SimpleEMR.getDateFormat().format(dob));
		System.out.println("Address:   " + address);
	}
}
