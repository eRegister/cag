package eh102.jemr;

public class TestEMR implements BasicEMR {

	@Override
	public void addPatient() {
		// TODO Auto-generated method stub

	}

	@Override
	public void addUser() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean authenticateUser(String login, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void deletePerson(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void findPatients(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getWelcomeMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void listPatients() {
		// TODO Auto-generated method stub

	}

	@Override
	public void listUsers() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean load() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void viewPatient(int id) {
		// TODO Auto-generated method stub

	}

}
